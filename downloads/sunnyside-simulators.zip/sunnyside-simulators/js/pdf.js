/*
 * Tiny dependency-free PDF writer used for exit tickets and facilitation guides.
 * Supports Helvetica / Helvetica-Bold text, word wrapping, lines, boxes and page breaks.
 */
(function (global) {
  // Helvetica advance widths (1/1000 em) for printable ASCII 32..126
  var W = [278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,278,278,584,584,584,556,1015,667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,667,778,722,667,611,722,667,944,667,667,611,278,278,278,469,556,333,556,556,500,556,556,278,556,556,222,222,500,222,833,556,556,556,556,333,500,278,556,500,722,500,500,500,334,260,334,584];
  var WIN = { '’': 146, '‘': 145, '“': 147, '”': 148, '–': 150, '—': 151, '•': 149, '…': 133, '×': 215, '÷': 247, '°': 176, '½': 189, '¼': 188, '¾': 190, 'é': 233, 'ñ': 241, 'í': 237, 'á': 225, 'ó': 243, 'ú': 250, '²': 178, '³': 179, '±': 177, '·': 183, '≈': 126, '≤': 60, '≥': 62, '→': 62, '−': 45 };

  function clean(s) {
    return String(s).replace(/<br\s*\/?>/gi, ' ').replace(/<sup>(.*?)<\/sup>/gi, '^$1').replace(/<[^>]+>/g, '')
      .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
.replace(/[₀-₉]/g, function (c) { return String(c.charCodeAt(0) - 8320); }).replace(/→/g, '->').replace(/←/g, '<-').replace(/✓/g, '(correct)').replace(/[−–]/g, '-').replace(/≈/g, '~').replace(/≥/g, '>=').replace(/≤/g, '<=')
      .replace(/\s+/g, ' ').trim();
  }
  function charCode(ch) {
    var c = ch.charCodeAt(0);
    if (c >= 32 && c <= 126) return c;
    if (WIN[ch] != null) return WIN[ch];
    if (c >= 160 && c <= 255) return c;
    return 63; // ?
  }
  function width(str, size, bold) {
    var w = 0;
    for (var i = 0; i < str.length; i++) {
      var c = charCode(str[i]);
      w += (c >= 32 && c <= 126) ? W[c - 32] : 556;
    }
    return w * size / 1000 * (bold ? 1.06 : 1);
  }
  function encode(str) {
    var out = '';
    for (var i = 0; i < str.length; i++) {
      var c = charCode(str[i]);
      var ch = String.fromCharCode(c);
      if (ch === '(' || ch === ')' || ch === '\\') out += '\\' + ch;
      else out += ch;
    }
    return out;
  }

  function Doc() {
    this.pages = [];
    this.pageW = 612; this.pageH = 792; this.margin = 54;
    this.newPage();
  }
  Doc.prototype.newPage = function () {
    this.ops = [];
    this.pages.push(this.ops);
    this.y = this.pageH - this.margin;
  };
  Doc.prototype.ensure = function (h) { if (this.y - h < this.margin) this.newPage(); };
  Doc.prototype.raw = function (s) { this.ops.push(s); };
  Doc.prototype.textAt = function (x, y, str, size, bold, gray) {
    this.raw((gray != null ? gray + ' g ' : '0 g ') + 'BT /' + (bold ? 'F2' : 'F1') + ' ' + size + ' Tf ' + x.toFixed(2) + ' ' + y.toFixed(2) + ' Td (' + encode(str) + ') Tj ET');
  };
  Doc.prototype.wrap = function (str, size, bold, maxW) {
    var words = clean(str).split(' '), lines = [], line = '';
    for (var i = 0; i < words.length; i++) {
      var test = line ? line + ' ' + words[i] : words[i];
      if (width(test, size, bold) > maxW && line) { lines.push(line); line = words[i]; }
      else line = test;
    }
    if (line) lines.push(line);
    return lines;
  };
  // paragraph: {size, bold, indent, gap, gray}
  Doc.prototype.para = function (str, o) {
    o = o || {};
    var size = o.size || 11, lead = size * 1.35, indent = o.indent || 0;
    var maxW = this.pageW - this.margin * 2 - indent;
    var lines = this.wrap(str, size, o.bold, maxW);
    for (var i = 0; i < lines.length; i++) {
      this.ensure(lead);
      this.y -= lead;
      this.textAt(this.margin + indent, this.y, lines[i], size, o.bold, o.gray);
    }
    this.y -= (o.gap != null ? o.gap : 4);
  };
  Doc.prototype.line = function (x1, y1, x2, y2, w, gray) {
    this.raw((gray != null ? gray : 0) + ' G ' + (w || 0.75) + ' w ' + x1.toFixed(2) + ' ' + y1.toFixed(2) + ' m ' + x2.toFixed(2) + ' ' + y2.toFixed(2) + ' l S');
  };
  Doc.prototype.rule = function (gap) {
    this.y -= (gap || 6);
    this.line(this.margin, this.y, this.pageW - this.margin, this.y, 0.75, 0.6);
    this.y -= (gap || 6);
  };
  Doc.prototype.writeLines = function (n, indent) {
    indent = indent || 0;
    for (var i = 0; i < n; i++) {
      this.ensure(24);
      this.y -= 24;
      this.line(this.margin + indent, this.y, this.pageW - this.margin, this.y, 0.5, 0.55);
    }
    this.y -= 6;
  };
  Doc.prototype.box = function (x, y, w, h, gray) {
    this.raw((gray != null ? gray : 0) + ' G 0.8 w ' + x.toFixed(2) + ' ' + y.toFixed(2) + ' ' + w.toFixed(2) + ' ' + h.toFixed(2) + ' re S');
  };
  Doc.prototype.fillBox = function (x, y, w, h, gray) {
    this.raw(gray + ' g ' + x.toFixed(2) + ' ' + y.toFixed(2) + ' ' + w.toFixed(2) + ' ' + h.toFixed(2) + ' re f');
  };
  Doc.prototype.footer = function (text) {
    for (var p = 0; p < this.pages.length; p++) {
      var s = text + '   ·   Page ' + (p + 1) + ' of ' + this.pages.length;
      this.pages[p].push('0.45 g BT /F1 8 Tf ' + this.margin + ' 30 Td (' + encode(s) + ') Tj ET');
    }
  };
  Doc.prototype.bytes = function () {
    var objs = [];
    objs[1] = '<< /Type /Catalog /Pages 2 0 R >>';
    objs[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
    objs[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
    var kids = [], n = 5;
    for (var p = 0; p < this.pages.length; p++) {
      var content = this.pages[p].join('\n');
      objs[n] = '<< /Length ' + content.length + ' >>\nstream\n' + content + '\nendstream';
      objs[n + 1] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + this.pageW + ' ' + this.pageH + '] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ' + n + ' 0 R >>';
      kids.push((n + 1) + ' 0 R');
      n += 2;
    }
    objs[2] = '<< /Type /Pages /Kids [' + kids.join(' ') + '] /Count ' + kids.length + ' >>';
    var out = '%PDF-1.4\n%âãÏÓ\n', offsets = [];
    for (var i = 1; i < objs.length; i++) {
      offsets[i] = out.length;
      out += i + ' 0 obj\n' + objs[i] + '\nendobj\n';
    }
    var xref = out.length;
    out += 'xref\n0 ' + objs.length + '\n0000000000 65535 f \n';
    for (var k = 1; k < objs.length; k++) out += ('0000000000' + offsets[k]).slice(-10) + ' 00000 n \n';
    out += 'trailer\n<< /Size ' + objs.length + ' /Root 1 0 R >>\nstartxref\n' + xref + '\n%%EOF';
    var bytes = new Uint8Array(out.length);
    for (var b = 0; b < out.length; b++) bytes[b] = out.charCodeAt(b) & 255;
    return bytes;
  };

  var LET = 'ABCDEFGH';
  var SUBJ = { science: [0.12, 0.49, 0.36], social: [0.78, 0.40, 0.13], ela: [0.47, 0.30, 0.70], math: [0.16, 0.42, 0.78] };
  function col(c) { return c[0].toFixed(3) + ' ' + c[1].toFixed(3) + ' ' + c[2].toFixed(3); }
  function tint(c, t) { return [c[0] + (1 - c[0]) * t, c[1] + (1 - c[1]) * t, c[2] + (1 - c[2]) * t]; }
  Doc.prototype.fillRGB = function (x, y, w, h, c) { this.raw(col(c) + ' rg ' + x.toFixed(2) + ' ' + y.toFixed(2) + ' ' + w.toFixed(2) + ' ' + h.toFixed(2) + ' re f'); };
  Doc.prototype.strokeRGB = function (x, y, w, h, c, lw) { this.raw(col(c) + ' RG ' + (lw || 1) + ' w ' + x.toFixed(2) + ' ' + y.toFixed(2) + ' ' + w.toFixed(2) + ' ' + h.toFixed(2) + ' re S'); };
  Doc.prototype.textRGB = function (x, y, str, size, bold, c) { this.raw(col(c) + ' rg BT /' + (bold ? 'F2' : 'F1') + ' ' + size + ' Tf ' + x.toFixed(2) + ' ' + y.toFixed(2) + ' Td (' + encode(str) + ') Tj ET'); };
  Doc.prototype.inner = function () { return this.pageW - this.margin * 2; };
  // colored section banner
  Doc.prototype.banner = function (title, c, right) {
    this.ensure(60); this.y -= 10;
    this.fillRGB(this.margin, this.y - 22, this.inner(), 24, c);
    this.textRGB(this.margin + 10, this.y - 15.5, title.toUpperCase(), 11.5, true, [1, 1, 1]);
    if (right) { var wr = width(right, 9.5, true); this.textRGB(this.pageW - this.margin - 10 - wr, this.y - 15.5, right, 9.5, true, [1, 1, 1]); }
    this.y -= 32;
  };
  Doc.prototype.sub = function (t, c) { this.ensure(90); this.y -= 4; this.para(t, { size: 11.5, bold: true, gap: 3 }); };
  // tinted box with wrapped paragraphs: items = [{label, text}] or strings
  Doc.prototype.callout = function (items, c, o) {
    o = o || {}; var self = this, pad = 9, size = o.size || 10.5, lead = size * 1.35, maxW = this.inner() - pad * 2 - 6;
    var lines = [];
    [].concat(items).forEach(function (it) {
      var label = it.label ? it.label + ' ' : '', text = typeof it === 'string' ? it : it.text;
      var ws = self.wrap(label + text, size, false, maxW);
      ws.forEach(function (l, k) { lines.push({ s: l, bold: k === 0 && !!it.label, label: k === 0 ? label : '' }); });
      lines.push(null);
    });
    lines.pop();
    var h = lines.reduce(function (a, l) { return a + (l ? lead : 4); }, 0) + pad * 2;
    if (h < 700) this.ensure(h + 6);
    this.fillRGB(this.margin, this.y - h, this.inner(), h, tint(c, 0.88));
    this.fillRGB(this.margin, this.y - h, 4, h, c);
    var yy = this.y - pad;
    lines.forEach(function (l) {
      if (!l) { yy -= 4; return; }
      yy -= lead;
      if (l.label) {
        self.textAt(self.margin + pad + 6, yy + 3, l.label.trim(), size, true);
        self.textAt(self.margin + pad + 9 + width(l.label, size, true), yy + 3, l.s.slice(l.label.length), size, false);
      } else self.textAt(self.margin + pad + 6, yy + 3, l.s, size, false);
    });
    this.y -= h + 8;
  };
  // table: cols = [{w (fraction), h (header)}], rows = [[cell strings]]
  Doc.prototype.table = function (cols, rows, c, o) {
    o = o || {}; var self = this, size = o.size || 9.5, lead = size * 1.3, pad = 5, W = this.inner();
    var ws = cols.map(function (k) { return k.w * W; });
    function rowH(cells, bold, minH) {
      var n = 1; cells.forEach(function (t, i) { n = Math.max(n, self.wrap(String(t == null ? '' : t), size, bold, ws[i] - pad * 2).length); });
      return Math.max(minH || 0, n * lead + pad * 2);
    }
    function draw(cells, bold, fill, minH) {
      var h = rowH(cells, bold, minH);
      if (self.y - h < self.margin) { self.newPage(); if (!bold && o.repeat !== false) draw(cols.map(function (k) { return k.h; }), true, c); }
      var x = self.margin;
      cells.forEach(function (t, i) {
        if (fill) self.fillRGB(x, self.y - h, ws[i], h, fill);
        self.strokeRGB(x, self.y - h, ws[i], h, [0.62, 0.66, 0.72], 0.6);
        var ls = self.wrap(String(t == null ? '' : t), size, bold, ws[i] - pad * 2);
        ls.forEach(function (l, k) { if (bold && fill === c) self.textRGB(x + pad, self.y - pad - lead * (k + 1) + 3, l, size, true, [1, 1, 1]); else self.textAt(x + pad, self.y - pad - lead * (k + 1) + 3, l, size, bold); });
        x += ws[i];
      });
      self.y -= h;
    }
    var hasHead = cols.some(function (k) { return k.h; });
    var need = (hasHead ? rowH(cols.map(function (k) { return k.h; }), true) : 0) + (rows.length ? rowH(rows[0], false, o.minH) : 0);
    if (this.y - need < this.margin) this.newPage();
    if (hasHead) draw(cols.map(function (k) { return k.h; }), true, c);
    rows.forEach(function (r, i) { draw(r, false, i % 2 ? tint(c, 0.94) : null, o.minH); });
    this.y -= 10;
  };
  Doc.prototype.checkbox = function (x, y) { this.box(x, y, 9, 9, 0.35); };
  Doc.prototype.nameDate = function () {
    var x = this.margin, y = this.y - 16;
    this.textAt(x, y, 'Name:', 11, true); this.line(x + 38, y - 2, x + 290, y - 2, 0.6, 0.4);
    this.textAt(x + 310, y, 'Date:', 11, true); this.line(x + 344, y - 2, this.pageW - this.margin, y - 2, 0.6, 0.4);
    this.y = y - 14;
  };

  function header(d, kicker, title, sub, c) {
    c = c || [0.15, 0.15, 0.15];
    d.fillRGB(d.margin, d.y - 6, d.inner(), 6, c);
    d.y -= 16;
    d.para(kicker, { size: 9, bold: true, gray: 0.35, gap: 0 });
    d.para(title, { size: 19, bold: true, gap: 2 });
    if (sub) d.para(sub, { size: 10, gray: 0.3, gap: 4 });
  }
  function blanks(note, show) { return note.replace(/\[([^\]]+)\]/g, function (_, w) { return show ? w.toUpperCase() : '_______________'; }); }
  var FRAMES = {
    CER: [['Claim', 'Answer the question in one sentence.', 2], ['Evidence', 'Give data or quote the text.', 3], ['Reasoning', 'Explain WHY the evidence supports your claim using a science idea.', 3]],
    RACE: [['Restate', 'Turn the question into a statement.', 1], ['Answer', 'Answer every part of the question.', 2], ['Cite', 'Quote the text in quotation marks.', 2], ['Explain', 'Explain how the evidence proves your answer.', 3]],
    SOURCE: [['Claim', 'Answer the question in one sentence.', 2], ['Evidence', 'Quote or cite facts from the source.', 2], ['Source check', 'Who made it, when, why? Can we trust it?', 2], ['Explain', 'Why does the evidence prove your claim?', 2]],
    MATH: [['Solve', 'Final answer with units.', 1], ['Show', 'Equation or steps with numbers and operations.', 3], ['Explain', 'Explain your strategy using math words.', 3]]
  };
  var FRAME_NAME = { CER: 'Claim-Evidence-Reasoning', RACE: 'RACE', SOURCE: 'Historian\'s Claim (Claim, Evidence, Source, Explain)', MATH: 'Solve-Show-Explain' };
  var NOTEBOOK = ['Answer in Part 2 of the lesson worksheet (or on this sheet).', 'Number each answer to match the question.', 'Answer in complete sentences. For math, show your work.', 'Work silently for 5 minutes, then share with a partner for 2 minutes.', 'Be ready to share one answer with the class.'];
  // The exit ticket keeps to three questions: two multiple choice and one short written answer.
  function exitItems(room, lesson) {
    var mcs = room.exit.filter(function (q) { return q.choices; }).slice(0, 2), ex = lesson && lesson.exit;
    var cr = ex ? null : room.exit.filter(function (q) { return !q.choices; })[0];
    return { mcs: mcs, cr: cr, ex: ex };
  }
  function exitPoints(room, lesson) { var it = exitItems(room, lesson); return { mc: it.mcs.length, cr: it.ex || it.cr ? 1 : 0, total: it.mcs.length + (it.ex || it.cr ? 3 : 0) }; }

  function exitTicket(room, std, lesson) {
    var d = new Doc(), c = SUBJ[room.subject] || [0.2, 0.2, 0.2], it = exitItems(room, lesson), ex = it.ex, pts = exitPoints(room, lesson), n = 0;
    header(d, 'EXIT TICKET  ·  GRADE ' + room.grade + '  ·  ' + room.standard, room.title, std ? std.title : '', c);
    d.nameDate();
    d.para('Circle the best answer for 1 and 2. Answer 3 in complete sentences.', { size: 10, gray: 0.35, gap: 6 });
    it.mcs.forEach(function (q) {
      n++;
      d.para(n + '.  ' + q.q, { size: 11, bold: true, gap: 3 });
      q.choices.forEach(function (ch, k) { d.para('(' + LET[k] + ')  ' + ch, { size: 10.5, indent: 18, gap: 1 }); });
      d.y -= 8;
    });
    if (ex) {
      n++;
      d.callout([{ label: 'Read:', text: String(ex.stim).replace(/^\s*Read:\s*/i, '') }], c, { size: 10 });
      d.para(n + '.  ' + ex.q, { size: 11, bold: true, gap: 2 });
      d.para('Use ' + FRAME_NAME[ex.frame].split(' (')[0] + ': ' + (FRAMES[ex.frame] || FRAMES.CER).map(function (f) { return f[0]; }).join(', ') + '.', { size: 9.5, gray: 0.35, indent: 18, gap: 2 });
      d.writeLines(5, 18);
    } else if (it.cr) {
      n++;
      d.para(n + '.  ' + it.cr.q, { size: 11, bold: true, gap: 3 });
      d.writeLines(4, 18);
    }
    // Teacher key
    d.newPage();
    header(d, 'TEACHER KEY  ·  ' + room.standard, room.title + ': Exit Ticket', 'Total: ' + pts.total + ' points. Mastery: ' + Math.ceil(pts.total * 0.8) + ' or more.', c);
    var rows = [], k = 0;
    it.mcs.forEach(function (q) { k++; rows.push([String(k), '(' + LET[q.answer] + ') ' + q.choices[q.answer], '1 point']); });
    if (ex) { k++; rows.push([String(k), ex.model + (ex.answer ? ' (Answer: ' + [].concat(ex.answer)[0] + (ex.unit ? ' ' + ex.unit : '') + ')' : ''), '3 points: ' + ex.look.slice(0, 3).join('; ') + '.']); }
    else if (it.cr) { k++; rows.push([String(k), it.cr.answer, '3 = accurate with a reason; 2 = accurate, no reason; 1 = partly accurate.']); }
    d.table([{ w: 0.06, h: '#' }, { w: 0.64, h: 'Answer' }, { w: 0.3, h: 'Points' }], rows, c);
    d.footer('The Broncho Escape · ' + room.title + ' · Exit Ticket');
    return d.bytes();
  }

  function warmup(room, std, lesson) {
    var d = new Doc(), c = SUBJ[room.subject] || [0.2, 0.2, 0.2];
    header(d, 'WARM-UP  ·  GRADE ' + room.grade + '  ·  ' + room.standard, std.title, 'Also Part 2 of the lesson worksheet.', c);
    d.nameDate();
    d.banner('Expectations', c, '5 min silent + 2 min share');
    NOTEBOOK.forEach(function (t, i) { d.para((i + 1) + '.  ' + t, { size: 10.5, indent: 6, gap: 2 }); });
    d.banner('Warm-up questions', c);
    lesson.warmup.forEach(function (w, i) { d.ensure(40 + w[2] * 24); d.para((i + 1) + '.  ' + w[0], { size: 11.5, bold: true, gap: 2 }); d.writeLines(w[2] + 1, 18); });
    d.callout([{ label: 'Today\'s target:', text: std.lesson.target }], c);
    d.newPage();
    header(d, 'TEACHER KEY  ·  WARM-UP', std.title, 'What to look for in student answers.', c);
    d.table([{ w: 0.06, h: '#' }, { w: 0.44, h: 'Question' }, { w: 0.5, h: 'Look for' }], lesson.warmup.map(function (w, i) { return [String(i + 1), w[0], w[1]]; }), c);
    d.para('Use the warm-up to activate prior knowledge. Call on 2–3 students, and write one strong answer on the board as a model. Question 3 previews today\'s lesson, so do not correct it yet; come back to it in the debrief.', { size: 10.5 });
    d.footer('The Broncho Escape · ' + std.code + ' · Warm-Up');
    return d.bytes();
  }

  // The lesson worksheet: one printable packet students complete as the presenter moves along.
  // Part numbers match the "Worksheet Part" badge on each presenter slide.
  function notes(room, std, lesson, key) {
    var d = new Doc(), c = SUBJ[room.subject] || [0.2, 0.2, 0.2], L = std.lesson, X = lesson, K = key;
    function ans(t) { if (K) d.para('Key: ' + t, { size: 10, indent: 18, gap: 4, gray: 0.25 }); }
    function lines(n, t) { if (K && t) ans(t); else d.writeLines(n, 18); }
    function part(n, title, right) { d.banner('Part ' + n + ': ' + title, c, right || ''); }
    function choices(ck) {
      if (ck.type === 'mc') { d.para('Circle one:   ' + ck.choices.map(function (ch, k) { return '(' + LET[k] + ') ' + ch; }).join('     '), { size: 10.5, indent: 18, gap: 2 }); }
      else if (ck.type === 'order') d.para('Number these in order:   ' + ck.items.slice().sort(function (a, b) { return a.length - b.length; }).map(function (x) { return '___ ' + x; }).join('    '), { size: 10.5, indent: 18, gap: 2 });
      else if (ck.type === 'highlight') d.para('Underline the answer:   ' + ck.segments.join(' '), { size: 10.5, indent: 18, gap: 2 });
      else d.para('Answer: ______________________ ' + (ck.unit || ''), { size: 10.5, indent: 18, gap: 2 });
    }
    function ckAns(ck) { return (ck.type === 'mc' ? '(' + LET[ck.answer] + ') ' + ck.choices[ck.answer] : ck.type === 'order' ? ck.items.join(' -> ') : ck.type === 'highlight' ? ck.answer.map(function (k) { return ck.segments[k]; }).join(' + ') : ck.answer[0] + (ck.unit ? ' ' + ck.unit : '')) + (ck.explain ? (/[.!?"']$/.test(String(ck.choices ? ck.choices[ck.answer] : '')) ? ' ' : '. ') + ck.explain : ''); }
    // Short version: one small task per part. Part numbers still match the presenter slides.
    function mini(n, title) { d.ensure(70); d.y -= 6; d.para('PART ' + n + '  ·  ' + title.toUpperCase(), { size: 10.5, bold: true, gap: 2 }); d.line(d.margin, d.y + 2, d.pageW - d.margin, d.y + 2, 0.8, 0.55); d.y -= 4; }
    header(d, (K ? 'TEACHER KEY  ·  ' : '') + 'LESSON WORKSHEET  ·  GRADE ' + room.grade + '  ·  ' + room.standard, std.title, 'Fill in each part when its number appears on the slide.', c);
    if (!K) d.nameDate();
    mini(1, 'Target');
    d.para(L.target, { size: 10.5, indent: 6, gap: 2 });
    mini(2, 'Warm-up');
    X.warmup.forEach(function (w, i) { d.ensure(44); d.para((i + 1) + '.  ' + w[0], { size: 10.5, gap: 0, indent: 6 }); lines(1, w[1]); });
    mini(3, 'Prediction');
    if (X.hook) { d.para(X.hook.q, { size: 10.5, indent: 6, gap: 1 }); d.para('Circle one:   ' + X.hook.options.map(function (o) { return '[ ] ' + o; }).join('      '), { size: 10.5, indent: 18, gap: 2 }); }
    mini(4, 'Vocabulary');
    d.table([{ w: 0.28, h: 'Word' }, { w: 0.72, h: 'Meaning' }], L.vocab.slice(0, 4).map(function (v) { return [v[0], K ? v[1] : '']; }), c, { minH: 24 });
    X.steps.forEach(function (st, i) {
      mini(5 + i, st.t);
      d.para(blanks(st.note, K), { size: 10.5, indent: 6, gap: 2 });
      d.para('Check: ' + st.check.q, { size: 10.5, indent: 6, gap: 1 });
      choices(st.check);
      if (K) ans(ckAns(st.check));
    });
    mini(9, 'Worked example');
    if (K) (X.model || []).forEach(function (t, k) { d.para((k + 1) + '.  ' + t, { size: 10, indent: 12, gap: 1 }); });
    else d.para('Final answer from the example: ________________________________________________', { size: 10.5, indent: 6, gap: 4 });
    if (X.wedo) {
      mini(10, 'We do');
      d.para(X.wedo.q, { size: 10.5, indent: 6, gap: 2 });
      d.para('Answer: ' + (K ? X.wedo.a : '____________________________________________'), { size: 10.5, indent: 6, gap: 4 });
    }
    if (X.youdo) {
      mini(11, 'You do');
      d.para(X.youdo.q, { size: 10.5, indent: 6, gap: 2 });
      choices(X.youdo);
      if (K) ans(ckAns(X.youdo));
    }
    mini(12, 'Work time: ' + room.title);
    var node = { escape: 'Lock', gallery: 'Exhibit', fieldtrip: 'Stop', mystery: 'File', quest: 'Level' }[room.format] || 'Stage';
    d.para('Write each code piece as you earn it:   ' + room.stages.map(function (st, i) { return node + ' ' + (room.format === 'gallery' ? 'ABCDEFGH'[i] : i + 1) + ': ' + (K ? (room.code || '')[i] || '' : '____'); }).join('    '), { size: 10.5, indent: 6, gap: 2 });
    d.para('Final code: ' + (K ? room.code || '' : '________________'), { size: 10.5, bold: true, indent: 6, gap: 4 });
    mini(13, 'Wrap-up');
    d.para('Was your prediction in Part 3 right? One thing I learned today:', { size: 10.5, indent: 6, gap: 0 }); lines(2, X.warmup[2][1]);
    d.footer('The Broncho Escape · ' + std.code + ' · Lesson Worksheet' + (K ? ' (Key)' : ''));
    return d.bytes();
  }

  function guide(room, std, answerLines, lesson) {
    var d = new Doc(), c = SUBJ[room.subject] || [0.2, 0.2, 0.2], L = std.lesson, X = lesson || {};
    header(d, 'FACILITATION GUIDE  ·  60-MINUTE LESSON  ·  GRADE ' + room.grade + '  ·  ' + room.standard, room.title, std.title + ': ' + std.text, c);
    d.callout([{ label: 'Learning target:', text: L.target }, { label: 'Success looks like:', text: 'Students use the vocabulary correctly, complete the ' + room.formatLabel.toLowerCase() + ', and score 80% or higher on the evidence-based exit ticket.' }, { label: 'Materials:', text: 'Student devices, the printed lesson worksheet (one per student), projector for the mini-lesson presenter.' }], c);
    d.banner('Lesson at a glance', c, '60 minutes');
    d.table([{ w: 0.13, h: 'Time' }, { w: 0.17, h: 'Part' }, { w: 0.4, h: 'Teacher does' }, { w: 0.3, h: 'Students do' }], [
      ['0:00–0:08', 'Warm-up', 'Project the warm-up. Circulate, then call on 2–3 students. Save question 3 for the debrief.', 'Answer Part 2 of the lesson worksheet; share with a partner.'],
      ['0:08–0:20', 'Mini-lesson', 'Teach with the 4-step presenter. Run each quick check with the whole class.', 'Complete worksheet Parts 4-11 as each slide appears; answer checks with fingers.'],
      ['0:20–0:48', room.formatLabel, 'Launch ' + room.title + '. Assign mission levels; circulate with the answer key.', 'Play solo or in pairs; record code pieces; complete any written evidence task.'],
      ['0:48–0:52', 'Debrief', 'Ask 2 debrief questions and revisit warm-up question 3.', 'Finish worksheet Part 13 (prediction check + one thing learned).'],
      ['0:52–1:00', 'Exit ticket', 'Hand out the exit ticket. Collect and sort with the mastery guide.', 'Answer with evidence independently.']], c);
    d.sub('Key vocabulary');
    d.table([{ w: 0.25, h: 'Word' }, { w: 0.75, h: 'Student-friendly definition' }], L.vocab, c);
    if (X.warmup) {
      d.banner('1. Warm-up', c, '0:00–0:08 · 8 min');
      d.callout([{ label: 'Warm-up expectations (post these):', text: NOTEBOOK.join(' ') }], c, { size: 10 });
      d.table([{ w: 0.06, h: '#' }, { w: 0.47, h: 'Question' }, { w: 0.47, h: 'Look for' }], X.warmup.map(function (w, i) { return [String(i + 1), w[0], w[1]]; }), c);
    }
    d.banner('2. Mini-lesson', c, '0:08–0:20 · 12 min');
    d.para('Project the Lesson presenter from the room page. It runs the whole hour: target and agenda, warm-up with timer, hook vote, 4 teaching steps (key idea, interactive tool, turn and talk, check for understanding), I do / we do / you do, a work-time screen with a timer and expectations, debrief, and the exit ticket. Press N for teacher notes, T to pause the timer, and P to pick a student.', { size: 10.5, gap: 4 });
    if (X.hook) d.callout([{ label: 'Hook (1 min):', text: X.hook.q + '  Class vote: ' + X.hook.options.join(' / ') }], c, { size: 10 });
    (X.steps || []).forEach(function (st, i) {
      var tool = st.tool ? (st.tool.sim ? 'Simulation: ' + st.tool.sim.title : Array.isArray(st.tool) ? 'Visual models' : 'Visual: ' + (st.tool.caption || st.tool.kind)) : st.cards ? 'Flip cards: ' + st.cards.map(function (x) { return x[0]; }).join(', ') : 'Board and notes';
      var ck = st.check, ans = ck.type === 'mc' ? '(' + LET[ck.answer] + ') ' + ck.choices[ck.answer] : ck.type === 'order' ? ck.items.join(' → ') : ck.type === 'highlight' ? ck.answer.map(function (k) { return ck.segments[k]; }).join(' + ') : ck.answer[0];
      d.sub('Step ' + (i + 1) + ' (3 min): ' + st.t);
      d.table([{ w: 0.2 }, { w: 0.8 }], [['Teach', st.say], ['Interactive tool', tool], ['Students do', (X.dos || [])[i] || st.do], ['Turn and talk', (X.talk || [])[i] || 'Explain the idea to a partner.'], ['Worksheet Part ' + (5 + i) + 'A', blanks(st.note, true)], ['Check for understanding', ck.q + '  Answer: ' + ans]], c, { repeat: false });
    });
    d.sub('I do: worked example (shown one step at a time)');
    (X.model || []).forEach(function (t, k) { d.para((k + 1) + '.  ' + t, { size: 10.5, indent: 10, gap: 1 }); });
    d.para('What to say on every slide is in the presenter script PDF.', { size: 10, gray: 0.35, gap: 4 });
    if (X.wedo) { d.sub('We do: guided practice'); d.para(X.wedo.q, { size: 10.5, bold: true, gap: 2 }); X.wedo.steps.forEach(function (t, k) { d.para((k + 1) + '.  ' + t, { size: 10.5, indent: 10, gap: 1 }); }); d.para('Answer: ' + X.wedo.a, { size: 10.5, gap: 4 }); }
    if (X.youdo) { var yd = X.youdo; d.sub('You do: independent check (2 min)'); d.para(yd.q + (yd.choices ? '  ' + yd.choices.map(function (c, k) { return '(' + LET[k] + ') ' + c; }).join('  ') : ''), { size: 10.5, gap: 2 }); d.para('Answer: ' + (yd.choices ? '(' + LET[yd.answer] + ') ' + yd.choices[yd.answer] : yd.answer[0]) + '. Students who miss it: 3-minute reteach at the teacher table, then start the room at the Explorer level.', { size: 10.5, gap: 4 }); }
    d.callout(L.misconceptions.map(function (m) { return { label: 'Misconception:', text: m }; }), [0.8, 0.45, 0.1], { size: 10 });
    d.banner('3. ' + room.formatLabel + ': ' + room.title, c, '0:20–0:48 · 28 min');
    d.para('Launch: project the start screen, read the story aloud, and assign mission levels (Explorer = extra support, Agent = on level, Legend = challenge). Students can open Supports any time for read-aloud, bigger text, a word bank, and a scratch pad.', { size: 10.5, gap: 4 });
    (room.runTips || []).forEach(function (t) { d.para('•  ' + t, { size: 10.5, indent: 10, gap: 2 }); });
    d.y -= 4;
    d.para('Students turn in: the completion code plus their copied "turn in your work" block (Canvas Text Entry).', { size: 10.5, bold: true, gap: 4 });
    d.banner('4. Debrief', c, '0:48–0:52 · 4 min');
    L.debrief.forEach(function (t, i) { d.para((i + 1) + '.  ' + t, { size: 10.5, indent: 6, gap: 2 }); });
    if (X.warmup) d.para('Close the loop: return to warm-up question 3. Answer: ' + X.warmup[2][1], { size: 10.5, gap: 4 });
    d.banner('5. Exit ticket', c, '0:52–1:00 · 8 min');
    d.para('Print the exit ticket PDF (page 2 is the key and mastery guide). Every item requires evidence: Part A asks students to justify each choice, Part B asks for an explanation, and Part C applies the standard to a new situation using ' + (X.exit ? FRAME_NAME[X.exit.frame] : 'a written response') + '. Sort results into Mastered, Approaching, and Beginning to plan tomorrow\'s groups.', { size: 10.5, gap: 4 });
    d.banner('Lesson resources', c);
    d.table([{ w: 0.3, h: 'Resource' }, { w: 0.7, h: 'How it fits the lesson' }], [
      ['Warm-up worksheet (PDF)', 'Optional standalone warm-up (also Part 2 of the lesson worksheet), with a key.'],
      ['Mini-lesson presenter', 'Projectable, step-by-step interactive lesson with tools and quick checks (room page).'],
      ['Lesson worksheet (PDF + key)', 'One printable packet students complete during the whole lesson: short fill-ins and quick checks in 13 small parts that match the presenter slides.'],
      [room.title + ' (.html)', 'The ' + room.formatLabel.toLowerCase() + ' for Canvas, with differentiated levels, supports, and a turn-in.'],
      ['Exit ticket (PDF + key)', 'Evidence-based check with a rubric and a mastery sorting guide.']].concat((std.resources || []).slice(0, 4).map(function (x) { return [x.name + ' (extra)', x.note + ' ' + x.url]; })), c);
    d.banner('Answer key: ' + room.title, c);
    answerLines.forEach(function (a) { d.para(a, { size: 9.5, indent: 6, gap: 1 }); });
    d.para('Final code: ' + room.finalCode, { size: 11, bold: true, gap: 6 });
    d.footer('The Broncho Escape · ' + room.title + ' · Facilitation Guide');
    return d.bytes();
  }

  // Teacher script that goes with the lesson presenter, slide by slide.
  function script(room, std, lesson, taskName) {
    var d = new Doc(), c = SUBJ[room.subject] || [0.2, 0.2, 0.2], L = std.lesson, X = lesson, n = 0;
    header(d, 'PRESENTER SCRIPT  ·  GRADE ' + room.grade + '  ·  ' + room.standard, std.title + ': teacher script', 'Use with the Lesson presenter (room page → Lesson presenter). Slides show only student cues; this script has what to say. Students need the printed lesson worksheet and a pencil.', c);
    d.callout([{ label: 'Presenter keys:', text: 'Right/left arrows change slides. N shows short notes. T pauses the timer. P picks a student. F is fullscreen.' }, { label: 'Response routine:', text: 'Students write each answer on their worksheet, then show it with fingers (1 = A, 2 = B, 3 = C, 4 = D). Scan the room before revealing.' }], c, { size: 10 });
    function slide(title, time, rows) {
      n++;
      d.banner('Slide ' + n + ': ' + title, c, time || '');
      d.table([{ w: 0.2 }, { w: 0.8 }], rows.filter(function (r) { return r && r[1]; }), c, { repeat: false });
    }
    slide('Today\'s target', '1 min', [['Say', 'Today\'s learning target is: "' + L.target + '" Read it with me.'], ['Say', 'Here is how you will know you have it: the success criteria. You will prove it on the exit ticket at the end of class.'], ['Point to', 'The agenda and the key vocabulary. Tell students they need their notebook, guided notes page, and pencil.']]);
    slide('Warm-up', '0:00–0:08', [['Say', 'Turn to Part 2 of your lesson worksheet. Answer the three questions in complete sentences. You have 5 minutes of silent work. Go.'], ['Do', 'Start the 8:00 timer. Circulate. At 5 minutes say: "Turn to your partner and compare answers for 2 minutes."'], ['Look for', X.warmup.map(function (w, i) { return (i + 1) + ') ' + w[1]; }).join('  ')], ['Say', 'Call on 2–3 students for questions 1 and 2, then reveal. Say: "We will come back to question 3 at the end of class."']]);
    slide('Hook', '1 min', [['Say', (X.hook ? 'Read the question on the screen: "' + X.hook.q + '" Circle your prediction in Part 3 of your worksheet and write why. Then vote.' : '')], ['Background', room.hook || L.hook], ['Do', 'Tap +1 for each vote. Do not give the answer. Say: "By the end of the lesson, you will be able to check your prediction."']]);
    X.steps.forEach(function (st, i) {
      var ck = st.check, ans = ck.type === 'mc' ? '(' + LET[ck.answer] + ') ' + ck.choices[ck.answer] : ck.type === 'order' ? ck.items.join(' -> ') : ck.type === 'highlight' ? ck.answer.map(function (k) { return ck.segments[k]; }).join(' + ') : ck.answer[0];
      slide('Learn ' + (i + 1) + ': ' + st.t, '3 min', [
        ['Say', st.say],
        ['Worksheet', 'Say: "Part ' + (5 + i) + ': fill in the blanks (A), do the task (B), write what your partner said (C), and answer the check (D)." Blank answers: ' + blanks(st.note, true) + ' (tap "Show the missing words" after students try.)'],
        ['Explore', (st.tool ? (st.tool.sim ? 'Run the simulation: ' + st.tool.sim.title + '. Before each change, ask students to predict in their notes.' : 'Point to the model: ' + (st.tool.caption || 'the picture') + '. Ask: "What do you notice?"') : st.cards ? 'Flip each card only after students guess: ' + st.cards.map(function (x) { return x[0] + ' = ' + x[1]; }).join('; ') + '.' : '') + ' Students do: ' + ((X.dos || [])[i] || st.do)],
        ['Turn and talk', 'Say: "' + ((X.talk || [])[i] || '') + '" Start the 1:00 timer. Then pick a pair to share.'],
        ['Check', 'Read the question aloud. Students write, then show fingers. Scan, then reveal. Answer: ' + ans + (ck.explain ? '. ' + ck.explain : '')],
        ['If < 80% correct', 'Go back to the Explore box and model a second example out loud, then re-ask the check with a partner discussion first. See "Misconceptions to watch for" at the end of this script.']
      ]);
    });
    slide('Worked example (I do)', '2 min', [['Say', 'Watch how I solve this. Write the final answer in Part 9 of your worksheet.'], ['Think aloud', L.model], ['Reveal', (X.model || []).join('  |  ')]]);
    if (X.wedo) slide('We do', '2 min', [['Say', 'Now we solve one together in Part 10. Read the problem with me.'], ['Do', 'Before revealing each step, ask: "What should we do next?" Take one answer, then tap "Show next step."'], ['Steps', X.wedo.steps.join('  |  ')], ['Answer', X.wedo.a]]);
    if (X.youdo) { var yd = X.youdo; slide('You do', '2 min', [['Say', 'Now on your own: Part 11. Solve it with no talking. You have 2 minutes.'], ['Answer', (yd.choices ? '(' + LET[yd.answer] + ') ' + yd.choices[yd.answer] : yd.answer[0]) + (yd.explain ? '. ' + yd.explain : '')], ['Then', 'Students who got it: launch the room. Students who missed it: 3-minute reteach at your table, then start the room at the Explorer level.']]); }
    slide('Work time: ' + room.title, '0:20–0:48', [['Say', 'Open ' + room.title + ' on your device. Type your name, choose the level I assigned, and begin. Whisper voice with your partner only.'], ['Do', 'Start the 28:00 timer and leave this slide up. Circulate with the answer key.'], ['Checkpoints', 'At 10 minutes: ' + (room.formatLabel === 'Gallery Walk' ? 'exhibit' : 'stage') + ' 2 done. At 20 minutes: stage 4 done; give a 5-minute warning for the ' + (taskName || 'final lock') + ' and turn-in.'], ['Turn-in', 'Students tap "Copy my work" and paste it into the Canvas assignment (Text Entry).']]);
    slide('Debrief', '0:48–0:52', [['Ask', L.debrief.join('  |  ')], ['Say', 'Back to warm-up question 3 and our hook vote: were our predictions right? What evidence changed your mind?'], ['Answer', X.warmup[2][1]]]);
    slide('Exit ticket', '0:52–1:00', [['Say', 'Clear your desk except a pencil. Work silently and on your own. For every answer, write "I know because..." and use evidence.'], ['Do', 'Hand out the exit ticket. Start the 8:00 timer. Collect and sort with page 3 (Mastered / Approaching / Beginning).']]);
    d.banner('Misconceptions to watch for', c);
    (L.misconceptions || []).forEach(function (m) { d.para('•  ' + m, { size: 10.5, indent: 6, gap: 3 }); });
    d.footer('The Broncho Escape · ' + std.code + ' · Presenter Script');
    return d.bytes();
  }

  function galleryGuide(room, std) {
    var d = new Doc(), c = SUBJ[room.subject] || [0.2, 0.2, 0.2];
    header(d, 'GALLERY WALK VIEWING GUIDE  ·  GRADE ' + room.grade + '  ·  ' + room.standard, room.title, 'Visit each poster. Find every numbered detail, then write what you see, think, and wonder.', c);
    d.nameDate();
    d.callout([{ label: 'Gallery etiquette:', text: 'Voice level 1. Stay with your group. Rotate when the timer sounds. Leave the poster the way you found it.' }], c, { size: 10 });
    room.stages.forEach(function (s, i) {
      if (!s.art) return;
      d.banner(String.fromCharCode(65 + i) + '. ' + s.art.title, c, s.art.spots.length + ' details to find');
      d.table([{ w: 0.33, h: 'I see... (2 details)' }, { w: 0.34, h: 'I think... (what it teaches)' }, { w: 0.33, h: 'I wonder...' }], [['', '', '']], c, { minH: 62 });
    });
    d.banner('After the walk', c);
    d.para('Which exhibit taught you the most? Explain using one detail from the poster.', { size: 11, bold: true, gap: 2 });
    d.writeLines(3);
    d.footer('The Broncho Escape · ' + room.title + ' · Gallery Walk Viewing Guide');
    return d.bytes();
  }

  global.CrossroadsPDF = { Doc: Doc, exitTicket: exitTicket, guide: guide, warmup: warmup, notes: notes, galleryGuide: galleryGuide, script: script, clean: clean };
  if (typeof module !== 'undefined') module.exports = global.CrossroadsPDF;
})(typeof window !== 'undefined' ? window : globalThis);
